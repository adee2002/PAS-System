"use strict";

const STORAGE_KEY = "student-module-projects-v1";

const state = {
  projects: [],
  filter: "All",
  query: "",
  editingId: null
};

const el = {
  form: document.getElementById("project-form"),
  formTitle: document.getElementById("form-title"),
  submitBtn: document.getElementById("submit-btn"),
  cancelEditBtn: document.getElementById("cancel-edit-btn"),
  list: document.getElementById("project-list"),
  search: document.getElementById("search"),
  chips: Array.from(document.querySelectorAll(".chip")),
  template: document.getElementById("project-card-template"),
  title: document.getElementById("title"),
  abstract: document.getElementById("abstract"),
  techStack: document.getElementById("techStack"),
  researchArea: document.getElementById("researchArea")
};

init();

function init() {
  state.projects = loadProjects();

  if (!state.projects.length) {
    state.projects = seedProjects();
    persistProjects();
  }

  bindEvents();
  render();
}

function bindEvents() {
  el.form.addEventListener("submit", onSubmit);
  el.cancelEditBtn.addEventListener("click", cancelEditMode);
  el.search.addEventListener("input", onSearch);

  for (const chip of el.chips) {
    chip.addEventListener("click", () => {
      state.filter = chip.dataset.filter;
      updateChipState();
      render();
    });
  }
}

function onSubmit(event) {
  event.preventDefault();

  const payload = getFormData();
  if (!payload) {
    return;
  }

  if (state.editingId) {
    const target = state.projects.find((project) => project.id === state.editingId);
    if (!target || target.status === "Matched") {
      cancelEditMode();
      return;
    }

    target.title = payload.title;
    target.abstract = payload.abstract;
    target.techStack = payload.techStack;
    target.researchArea = payload.researchArea;
    target.updatedAt = new Date().toISOString();
  } else {
    state.projects.unshift({
      id: crypto.randomUUID(),
      ...payload,
      status: "Pending",
      createdAt: new Date().toISOString(),
      updatedAt: null
    });
  }

  persistProjects();
  cancelEditMode();
  render();
}

function getFormData() {
  const title = el.title.value.trim();
  const abstract = el.abstract.value.trim();
  const techStack = el.techStack.value.trim();
  const researchArea = el.researchArea.value.trim();

  if (!title || !abstract || !techStack || !researchArea) {
    return null;
  }

  return { title, abstract, techStack, researchArea };
}

function onSearch() {
  state.query = el.search.value.trim().toLowerCase();
  render();
}

function render() {
  el.list.innerHTML = "";

  const visible = state.projects.filter((project) => {
    const statusMatch = state.filter === "All" || project.status === state.filter;
    const queryMatch =
      !state.query ||
      project.title.toLowerCase().includes(state.query) ||
      project.researchArea.toLowerCase().includes(state.query);

    return statusMatch && queryMatch;
  });

  if (!visible.length) {
    el.list.appendChild(renderEmpty());
    return;
  }

  visible.forEach((project, index) => {
    const node = renderCard(project, index);
    el.list.appendChild(node);
  });
}

function renderCard(project, index) {
  const clone = el.template.content.cloneNode(true);
  const card = clone.querySelector(".project-card");
  card.style.setProperty("--i", String(index));

  const title = clone.querySelector(".project-title");
  const abstract = clone.querySelector(".project-abstract");
  const stack = clone.querySelector(".project-stack");
  const area = clone.querySelector(".project-area");
  const date = clone.querySelector(".project-date");
  const badge = clone.querySelector(".badge");

  const editBtn = clone.querySelector(".btn-edit");
  const deleteBtn = clone.querySelector(".btn-delete");

  title.textContent = project.title;
  abstract.textContent = project.abstract;
  stack.textContent = project.techStack;
  area.textContent = project.researchArea;
  badge.textContent = project.status;
  date.textContent = `Submitted ${formatDate(project.createdAt)}`;

  const isMatched = project.status === "Matched";
  badge.className = `badge ${statusClass(project.status)}`;

  editBtn.disabled = isMatched;
  deleteBtn.disabled = isMatched;

  editBtn.addEventListener("click", () => enterEditMode(project.id));
  deleteBtn.addEventListener("click", () => deleteProject(project.id));

  return clone;
}

function renderEmpty() {
  const empty = document.createElement("div");
  empty.className = "empty";
  empty.innerHTML = `
    <h3>No projects found</h3>
    <p>Try another status filter, search term, or submit a new project.</p>
  `;
  return empty;
}

function enterEditMode(id) {
  const target = state.projects.find((project) => project.id === id);
  if (!target || target.status === "Matched") {
    return;
  }

  state.editingId = id;
  el.title.value = target.title;
  el.abstract.value = target.abstract;
  el.techStack.value = target.techStack;
  el.researchArea.value = target.researchArea;

  el.formTitle.textContent = "Edit Project";
  el.submitBtn.textContent = "Update Project";
  el.cancelEditBtn.classList.remove("hidden");

  window.scrollTo({ top: 0, behavior: "smooth" });
}

function cancelEditMode() {
  state.editingId = null;
  el.form.reset();
  el.formTitle.textContent = "Submit Project";
  el.submitBtn.textContent = "Submit Project";
  el.cancelEditBtn.classList.add("hidden");
}

function deleteProject(id) {
  const target = state.projects.find((project) => project.id === id);
  if (!target || target.status === "Matched") {
    return;
  }

  state.projects = state.projects.filter((project) => project.id !== id);
  persistProjects();
  render();
}

function updateChipState() {
  for (const chip of el.chips) {
    const active = chip.dataset.filter === state.filter;
    chip.classList.toggle("active", active);
    chip.setAttribute("aria-selected", String(active));
  }
}

function loadProjects() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return [];
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function persistProjects() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state.projects));
}

function statusClass(status) {
  switch (status) {
    case "Under Review":
      return "review";
    case "Matched":
      return "matched";
    default:
      return "pending";
  }
}

function formatDate(isoDate) {
  return new Date(isoDate).toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric"
  });
}

function seedProjects() {
  const now = Date.now();
  return [
    {
      id: crypto.randomUUID(),
      title: "AI Project Topic Matcher",
      abstract: "A recommendation-driven platform that maps student topics to suitable supervisors using weighted relevance.",
      techStack: "ASP.NET Core, React, SQL Server",
      researchArea: "Artificial Intelligence",
      status: "Pending",
      createdAt: new Date(now - 86400000 * 2).toISOString(),
      updatedAt: null
    },
    {
      id: crypto.randomUUID(),
      title: "Cloud-Based Progress Tracker",
      abstract: "A web dashboard for milestones, feedback loops, and risk indicators during final-year project supervision.",
      techStack: "ASP.NET Core MVC, EF Core, Bootstrap",
      researchArea: "Cloud Computing",
      status: "Under Review",
      createdAt: new Date(now - 86400000 * 4).toISOString(),
      updatedAt: null
    },
    {
      id: crypto.randomUUID(),
      title: "Secure Web Threat Visualizer",
      abstract: "A threat-analysis interface to map attack vectors, mitigation patterns, and testing evidence for web systems.",
      techStack: "ASP.NET Core, Chart.js, SQL Server",
      researchArea: "Cybersecurity",
      status: "Matched",
      createdAt: new Date(now - 86400000 * 7).toISOString(),
      updatedAt: null
    }
  ];
}
